#include<stdio.h>
int main()
{
    float p,t,r,si;
    printf("enter ptr values\n" );
    scanf("%f %f %f",&p,&t,&r);
    si=p*t*r/100;
    printf("the si of  is %f",si);
    return 0;
    
}