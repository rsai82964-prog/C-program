#include<stdio.h>
int main()
{
    int length,width,area,perimeter;
    printf("enter length of the rectangle");
    scanf("%d",&length);
    printf("nter the width of the rectangle");
    scanf("%d",&width);
    area=length*width;
    perimeter=2*(length+width);
    printf("area of rectangle=%.2d\n",area);
    printf("perimeter of rectangle=%.2d\n",perimeter);
    return 0;
    
}
