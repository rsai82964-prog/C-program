#include <stdio.h>;
int main()
{
    printf("welcome to my world\n");
    printf("my name is rahul");
    return 0;
    
}