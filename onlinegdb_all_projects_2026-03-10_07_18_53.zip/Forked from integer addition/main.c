#include<stdio.h>
int main()
{
    int a,b,sum;
    printf("enter the 2 values\n");
    scanf("%d%d",&a,&b);
    sum=a+b;
    printf("the add of integers is the %d",sum);
    return 0;
    
    
}
