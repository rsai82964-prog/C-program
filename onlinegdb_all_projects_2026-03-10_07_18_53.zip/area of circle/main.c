#include<stdio.h>
int main()\
{
    int r;
    float area;
    printf("enter the r value\n");
    scanf("%d",&r);
    area=3.14*r*r;
    printf("the area of circle is %f",area);
    return 0;
}