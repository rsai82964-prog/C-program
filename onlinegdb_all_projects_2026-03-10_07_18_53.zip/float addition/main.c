#include<stdio.h>
int main()
{
    float a,b,sum;
    printf("enter the 2 values\n");
    scanf("%f %f",&a,&b);
    sum=a+b;
    printf("the add of the float %.2",sum);
    return 0;
}
