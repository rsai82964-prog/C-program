#include<stdio.h>
int main()
{
    int side;
    int area;
    scanf("%d",&side);
    area=side*side;
    printf("the area of the square is %d",area);
    return 0;
    
}